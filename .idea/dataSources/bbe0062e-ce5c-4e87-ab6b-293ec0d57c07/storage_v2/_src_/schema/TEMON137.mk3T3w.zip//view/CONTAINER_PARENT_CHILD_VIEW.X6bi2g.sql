CREATE VIEW CONTAINER_PARENT_CHILD_VIEW AS
  select parent.name container, child.name child_container
from container parent inner join container child on child.parent_container_id = parent.container_id
order by parent.container_id
/

