CREATE VIEW USER_MESSAGES_VIEW AS
  select author.login author, recipient.login recipient,pm.private_message_id pid, pm.text
from "USER" author, "USER" recipient, private_message pm
where pm.author_id = author.user_id
and pm.recipient_id = recipient.user_id
order by author.user_id
/

