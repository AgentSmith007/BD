CREATE TRIGGER MESSAGE_REDACTION_MESSAGE_REDA
  BEFORE INSERT
  ON MESSAGE_REDACTION
  FOR EACH ROW
  WHEN ( FOR EACH ROW )
BEGIN
    :new.message_redaction_id := message_redaction_message_reda.nextval;
END;
/

