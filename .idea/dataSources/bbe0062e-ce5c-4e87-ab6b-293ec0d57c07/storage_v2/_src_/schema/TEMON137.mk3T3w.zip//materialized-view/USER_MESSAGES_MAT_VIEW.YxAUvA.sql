CREATE MATERIALIZED VIEW USER_MESSAGES_MAT_VIEW
NEVER REFRESH
  AS
    select author.login author, recipient.login recipient, pm.text
from "USER" author, "USER" recipient, private_message pm
where pm.author_id = author.user_id
and pm.recipient_id = recipient.user_id
/

