CREATE VIEW THEME_MESSAGES_VIEW AS
  select forum.NAME forum, theme.name theme, us.login author, fm.text text
from container theme right join forum_message fm on theme.CONTAINER_ID = fm.CONTAINER_ID, "USER" us, container forum
where us.user_id = fm.author_id
and forum.CONTAINER_ID = theme.PARENT_CONTAINER_ID
order by forum.container_id, theme.container_id, us.user_id, fm.FORUM_MESSAGE_ID
/

