CREATE TRIGGER CONTAINER_CONTAINER_ID_TRG
  BEFORE INSERT
  ON CONTAINER
  FOR EACH ROW
  WHEN ( FOR EACH ROW )
BEGIN
    :new.container_id := container_container_id_seq.nextval;
END;
/

