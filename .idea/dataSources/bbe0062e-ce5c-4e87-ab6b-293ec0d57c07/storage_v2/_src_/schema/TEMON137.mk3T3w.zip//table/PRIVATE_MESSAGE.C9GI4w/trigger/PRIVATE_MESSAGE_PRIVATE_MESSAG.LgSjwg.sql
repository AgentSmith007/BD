CREATE TRIGGER PRIVATE_MESSAGE_PRIVATE_MESSAG
  BEFORE INSERT
  ON PRIVATE_MESSAGE
  FOR EACH ROW
  WHEN ( FOR EACH ROW )
BEGIN
    :new.private_message_id := private_message_private_messag.nextval;
END;
/

