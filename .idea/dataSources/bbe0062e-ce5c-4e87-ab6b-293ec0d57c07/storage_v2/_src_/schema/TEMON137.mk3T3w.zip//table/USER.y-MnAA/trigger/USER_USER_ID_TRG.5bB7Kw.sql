CREATE TRIGGER USER_USER_ID_TRG
  BEFORE INSERT
  ON "USER"
  FOR EACH ROW
  WHEN ( FOR EACH ROW )
BEGIN
    :new.user_id := user_user_id_seq.nextval;
END;
/

