CREATE TRIGGER FORUM_MESSAGE_FORUM_MESSAGE_ID
BEFORE INSERT
  ON FORUM_MESSAGE
FOR EACH ROW WHEN (FOR EACH ROW )
BEGIN
    :new.forum_message_id := forum_message_forum_message_id.nextval;
END;
/
