CREATE VIEW NAME_USER_VIEW AS SELECT "CONTAINER_ID","PARENT_CONTAINER_ID","CREATOR_ID","NAME","CREATION_DATE","NAME_USER"
FROM container
where name = 'Theme1'
and Name_User = (select user from dual)
/
