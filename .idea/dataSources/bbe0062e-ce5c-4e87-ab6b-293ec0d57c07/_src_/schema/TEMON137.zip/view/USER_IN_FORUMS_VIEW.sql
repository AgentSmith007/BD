CREATE VIEW USER_IN_FORUMS_VIEW AS select DISTINCT us.login author, forum.name forum
from "USER" us, container theme right join forum_message fm on theme.CONTAINER_ID = fm.CONTAINER_ID, container forum
where us.user_id = fm.author_id
and forum.CONTAINER_ID = theme.PARENT_CONTAINER_ID
order by us.login, forum.name
/
