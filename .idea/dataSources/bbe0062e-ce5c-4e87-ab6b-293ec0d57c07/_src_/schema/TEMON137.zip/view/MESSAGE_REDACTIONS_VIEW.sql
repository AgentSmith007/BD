CREATE VIEW MESSAGE_REDACTIONS_VIEW AS select us.login redactor, fm.text current_text, mr.redaction_reason reason, mr.old_text as "OLD_TEXT"
from forum_message fm, message_redaction mr, "USER" us
where fm.forum_message_id = mr.redacted_message_id
and mr.redactor_id = us.user_id
order by fm.FORUM_MESSAGE_ID
/
