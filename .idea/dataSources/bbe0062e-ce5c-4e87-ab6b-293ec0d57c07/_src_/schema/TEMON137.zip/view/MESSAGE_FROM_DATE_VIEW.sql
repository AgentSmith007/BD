CREATE VIEW MESSAGE_FROM_DATE_VIEW AS select fm.sent_date, us.login author, theme.name theme, fm.text text
from container theme right join forum_message fm on theme.CONTAINER_ID = fm.CONTAINER_ID, "USER" us
where us.user_id = fm.author_id
order by fm.sent_date
/
