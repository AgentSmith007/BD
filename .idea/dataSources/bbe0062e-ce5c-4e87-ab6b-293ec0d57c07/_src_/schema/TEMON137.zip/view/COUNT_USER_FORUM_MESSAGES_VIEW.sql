CREATE VIEW COUNT_USER_FORUM_MESSAGES_VIEW AS select us.login, count(fm.forum_message_id) as "COUNT MESSAGES"
from "USER" us, forum_message fm
where us.user_id = fm.author_id
group by us.user_id, us.login
order by us.user_id
/
