CREATE Procedure Update_Employee(Id_em Number,Fio_em Varchar2,
Phone_em Number,Email_em Varchar2,Age_em Number,NameUser_em Varchar2)
is
Fio_Already_Exist EXCEPTION;
Employee_Fio_Exist VARCHAR2(70);
Employee_Exist Varchar2(70);
begin
select FIO into Employee_Exist from EMPLOYEE
where id=id_em;
if Employee_Exist is not null then
begin
select FIO into Employee_Fio_Exist from EMPLOYEE where FIO=Fio_em;
Raise Fio_Already_Exist;
EXCEPTION
WHEN NO_DATA_FOUND THEN
begin
Update EMPLOYEE set FIO=Fio_em,Age=Age_em,Email=Email_em,
Phone=Phone_em,NameUser=NameUser_em where Id=Id_em;
commit;
end;
when Fio_Already_Exist then
begin
DBMS_OUTPUT.PUT_LINE('Задайте другую фамилию');
RAISE_APPLICATION_ERROR(-20001,'Пользователь с таким ФИО уже существует!');
end;    
end;
else RAISE_APPLICATION_ERROR(-20001,'ПОЛЬЗОВАТЕЛЯ С ТАКИМ ID НЕ СУЩЕСТВУЕТ!');
end if;
end;
/
