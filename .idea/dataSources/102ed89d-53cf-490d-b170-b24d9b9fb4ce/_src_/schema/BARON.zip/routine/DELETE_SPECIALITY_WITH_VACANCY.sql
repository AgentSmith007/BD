CREATE Procedure Delete_Speciality_With_Vacancy(Deleted_Speciality NUMBER)
is
Curr_User varchar(30);
begin
select USER 
into Curr_User
From dual;
if(Curr_User In ('BBB','SYS')) then
begin
Delete from VACANCY Where Id In
(Select Id FROM Vacancy WHERE Speciality_Id = Deleted_Speciality );
Delete from SPECIALITY where Id = Deleted_Speciality;
end;
else
Raise_Application_Error(-20001,'Вы не входите в список пользователей которым позволено выполнить данную операцию!');    
end if;
end;
/
