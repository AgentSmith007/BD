CREATE Procedure Add_New_Employee(
Fio_em Varchar2,Phone_em Number,Email_em Varchar2,Age_em Number,NameUser_em Varchar2)
is
Curr_User varchar(30);
Fio_Already_Exist EXCEPTION;
Employee_Fio_Exist VARCHAR2(70);
begin
select USER 
into Curr_User
From dual;
if(Curr_User In ('BBB','SYS')) then
begin
Select FIO into Employee_Fio_Exist from EMPLOYEE where FIO=Fio_em;
Raise Fio_Already_Exist;
EXCEPTION
WHEN NO_DATA_FOUND THEN
begin
insert into Employee values(NEW_USER.NextVal,Fio_em,Phone_em,Email_em,Age_em,NameUser_em);
commit;
end;
when Fio_Already_Exist then
begin
DBMS_OUTPUT.PUT_LINE('Задайте другую фамилию');
RAISE_APPLICATION_ERROR(-20001,'Пользователь с такой фамилией уже существует!');
end;    
end;
else
Raise_Application_Error(-20001,'Вы не входите в список пользователей которым позволено выполнить данную операцию!');    
end if;
end;
/
