CREATE Procedure Delete_Enterprise_With_Vacancy(Deleted_Enterprise NUMBER)
is
begin
Delete from VACANCY Where Id In
(Select Id FROM Vacancy WHERE Enterprise_Id = Deleted_Enterprise);
Delete from Enterprise where Id = Deleted_Enterprise;
end;
/
