CREATE Package EmployeePackage is
Procedure Add_New_Employee(
Fio_em Varchar2,Phone_em Number,Email_em Varchar2,Age_em Number,NameUser_em Varchar2);
 Procedure Update_Employee(Id_em Number,Fio_em Varchar2,
Phone_em Number,Email_em Varchar2,Age_em Number,NameUser_em Varchar2);
end EmployeePackage;
/
